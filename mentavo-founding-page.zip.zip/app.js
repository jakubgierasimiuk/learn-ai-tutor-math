// Mentavo AI Founding 100 Landing Page JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all functionality
    initStickyHeader();
    initFAQAccordion();
    initSignupForm();
    initModal();
    initScrollAnimations();
    initCounterUpdates();
    initSmoothScrolling();
    initCTAButtons();
    initInfoButton();
    
    console.log('🚀 Mentavo AI Founding 100 Landing Page loaded successfully!');
});

// Sticky Header on Scroll
function initStickyHeader() {
    const header = document.getElementById('header');
    
    if (header) {
        window.addEventListener('scroll', function() {
            const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
            
            if (scrollTop > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
    }
}

// FAQ Accordion Functionality
function initFAQAccordion() {
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-item__question');
        const answer = item.querySelector('.faq-item__answer');
        
        if (question && answer) {
            question.addEventListener('click', function() {
                const isActive = item.classList.contains('active');
                
                // Close all other FAQ items
                faqItems.forEach(otherItem => {
                    if (otherItem !== item) {
                        otherItem.classList.remove('active');
                        const otherAnswer = otherItem.querySelector('.faq-item__answer');
                        if (otherAnswer) {
                            otherAnswer.style.maxHeight = '0';
                        }
                    }
                });
                
                // Toggle current item
                if (isActive) {
                    item.classList.remove('active');
                    answer.style.maxHeight = '0';
                } else {
                    item.classList.add('active');
                    answer.style.maxHeight = answer.scrollHeight + 'px';
                    
                    // Track FAQ interaction
                    trackEvent('FAQ Opened', {
                        question: question.textContent.trim()
                    });
                }
            });
        }
    });
}

// Signup Form Functionality
function initSignupForm() {
    const form = document.getElementById('founding-form');
    const submitButton = form?.querySelector('button[type="submit"]');
    
    if (form && submitButton) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(form);
            const email = formData.get('email');
            const name = formData.get('name');
            const consent = formData.get('consent');
            
            // Validate form
            if (!email || !name || !consent) {
                showNotification('Proszę wypełnić wszystkie pola i zaakceptować zgodę.', 'error');
                return;
            }
            
            if (!isValidEmail(email)) {
                showNotification('Proszę podać prawidłowy adres email.', 'error');
                return;
            }
            
            // Show loading state
            submitButton.classList.add('loading');
            submitButton.disabled = true;
            
            // Simulate API call
            setTimeout(() => {
                handleFoundingSignup({ email, name });
                submitButton.classList.remove('loading');
                submitButton.disabled = false;
                
                // Reset form
                form.reset();
            }, 1500);
        });
    }
}

// Handle Founding Member Signup
function handleFoundingSignup(userData) {
    // Track successful signup
    trackEvent('Founding Member Signup', {
        email: userData.email,
        name: userData.name,
        timestamp: new Date().toISOString()
    });
    
    // Update counter (simulate decrement)
    updateMemberCounter();
    
    // Show success modal
    showThankYouModal();
    
    // In real implementation, send data to backend
    console.log('Founding Member signup:', userData);
    
    // Optional: Send to actual endpoint
    // fetch('/api/founding-signup', {
    //     method: 'POST',
    //     headers: { 'Content-Type': 'application/json' },
    //     body: JSON.stringify(userData)
    // });
}

// Modal Functionality
function initModal() {
    const modal = document.getElementById('thank-you-modal');
    const closeButton = document.getElementById('modal-close');
    
    if (modal && closeButton) {
        closeButton.addEventListener('click', closeModal);
        
        // Close modal when clicking outside
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                closeModal();
            }
        });
        
        // Close modal with Escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && !modal.classList.contains('hidden')) {
                closeModal();
            }
        });
    }
}

function showThankYouModal() {
    const modal = document.getElementById('thank-you-modal');
    if (modal) {
        modal.classList.remove('hidden');
        document.body.style.overflow = 'hidden';
        
        // Track modal view
        trackEvent('Thank You Modal Viewed');
    }
}

function closeModal() {
    const modal = document.getElementById('thank-you-modal');
    if (modal) {
        modal.classList.add('hidden');
        document.body.style.overflow = '';
    }
}

// Scroll Animations
function initScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-on-scroll');
                
                // Add stagger effect for grid items
                const gridItems = entry.target.querySelectorAll(
                    '.problem-card, .feature-card, .benefit-card, .step-card, .trust-item'
                );
                gridItems.forEach((item, index) => {
                    setTimeout(() => {
                        item.style.animationDelay = `${index * 0.1}s`;
                        item.classList.add('animate-on-scroll');
                    }, index * 100);
                });
            }
        });
    }, observerOptions);

    // Observe sections for animation
    const sectionsToAnimate = document.querySelectorAll('section:not(.hero)');
    sectionsToAnimate.forEach(section => {
        observer.observe(section);
    });
}

// Counter Updates
function initCounterUpdates() {
    const spotsLeftElements = document.querySelectorAll('#spots-left');
    const memberCounterElements = document.querySelectorAll('#member-counter');
    
    // Initialize with current values
    const currentSpotsLeft = 87; // From JSON data
    const currentMemberCount = 100 - currentSpotsLeft;
    
    spotsLeftElements.forEach(el => el.textContent = currentSpotsLeft);
    memberCounterElements.forEach(el => el.textContent = currentMemberCount + 1);
}

function updateMemberCounter() {
    const spotsLeftElements = document.querySelectorAll('#spots-left');
    const memberCounterElements = document.querySelectorAll('#member-counter');
    
    spotsLeftElements.forEach(el => {
        const currentSpots = parseInt(el.textContent);
        if (currentSpots > 0) {
            el.textContent = currentSpots - 1;
        }
    });
    
    memberCounterElements.forEach(el => {
        const currentCount = parseInt(el.textContent);
        el.textContent = currentCount + 1;
    });
}

// Smooth Scrolling
function initSmoothScrolling() {
    const links = document.querySelectorAll('a[href^="#"]');
    
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                const headerHeight = document.getElementById('header')?.offsetHeight || 0;
                const targetPosition = targetElement.offsetTop - headerHeight - 20;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
}

// CTA Button Interactions - FIXED
function initCTAButtons() {
    // Get all CTA buttons with multiple selectors to ensure we catch all
    const ctaButtons = document.querySelectorAll(
        '.hero__cta, .header__cta .btn, .btn--primary, button[class*="btn--primary"]'
    );
    
    console.log('Found CTA buttons:', ctaButtons.length); // Debug log
    
    ctaButtons.forEach((button, index) => {
        console.log(`CTA Button ${index + 1}:`, button.textContent.trim()); // Debug log
        
        // Only attach to buttons that should scroll to form
        const buttonText = button.textContent.trim().toLowerCase();
        if (buttonText.includes('zostań') || buttonText.includes('founding') || buttonText.includes('member')) {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                
                console.log('CTA button clicked:', this.textContent.trim()); // Debug log
                
                // Scroll to signup form
                scrollToSignupForm();
                
                // Track CTA click
                trackEvent('CTA Clicked', {
                    button_text: this.textContent.trim(),
                    location: this.closest('section')?.className || this.closest('header') ? 'header' : 'unknown'
                });
            });
            
            // Add hover effects
            button.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-2px)';
            });
            
            button.addEventListener('mouseleave', function() {
                this.style.transform = '';
            });
        }
    });
}

// Helper function to scroll to signup form
function scrollToSignupForm() {
    const signupForm = document.getElementById('founding-form');
    const finalCtaSection = document.querySelector('.final-cta');
    
    const targetElement = signupForm || finalCtaSection;
    
    if (targetElement) {
        const headerHeight = document.getElementById('header')?.offsetHeight || 80;
        const targetPosition = targetElement.offsetTop - headerHeight - 40;
        
        console.log('Scrolling to signup form at position:', targetPosition); // Debug log
        
        window.scrollTo({
            top: targetPosition,
            behavior: 'smooth'
        });
        
        // Focus on first input after scroll
        setTimeout(() => {
            const firstInput = document.querySelector('#founding-form input[type="email"]');
            if (firstInput) {
                firstInput.focus();
                console.log('Focused on email input'); // Debug log
            }
        }, 800);
    } else {
        console.error('Signup form not found!'); // Debug log
    }
}

// Info Button (Secondary CTA)
function initInfoButton() {
    const infoButton = document.getElementById('info-btn');
    
    if (infoButton) {
        infoButton.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Show email collection modal or form
            showInfoRequestModal();
            
            // Track info request
            trackEvent('Info Request Clicked');
        });
    }
}

function showInfoRequestModal() {
    // Create a simple prompt for email (in production, use a proper modal)
    const email = prompt('Podaj swój adres email, a wyślemy Ci więcej informacji o Mentavo AI:');
    
    if (email && isValidEmail(email)) {
        // Track email collection
        trackEvent('Info Email Collected', { email });
        
        showNotification('Dziękujemy! Wyślemy Ci szczegółowe informacje na podany adres.', 'success');
        
        // In production, send to backend
        console.log('Info request email:', email);
    } else if (email) {
        showNotification('Proszę podać prawidłowy adres email.', 'error');
    }
}

// Utility Functions
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Notification System
function showNotification(message, type = 'info') {
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => notification.remove());
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification--${type}`;
    
    const icon = type === 'success' ? '✅' : type === 'error' ? '❌' : 'ℹ️';
    notification.innerHTML = `
        <div class="notification__content">
            <span class="notification__icon">${icon}</span>
            <span class="notification__message">${message}</span>
        </div>
    `;
    
    // Add notification styles
    const bgColor = type === 'success' ? '#10B981' : type === 'error' ? '#EF4444' : '#3B82F6';
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${bgColor};
        color: white;
        padding: 16px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        z-index: 10000;
        transform: translateX(100%);
        transition: transform 0.3s ease;
        max-width: 350px;
        font-family: 'Inter', sans-serif;
        font-weight: 500;
    `;
    
    notification.querySelector('.notification__content').style.cssText = `
        display: flex;
        align-items: center;
        gap: 10px;
    `;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 10);
    
    // Auto remove after 4 seconds
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 4000);
}

// Analytics Tracking
function trackEvent(eventName, properties = {}) {
    console.log('📊 Event tracked:', eventName, properties);
    
    // In real implementation, send to analytics service
    // gtag('event', eventName, properties);
    // or
    // analytics.track(eventName, properties);
    
    // Example: Send to custom analytics endpoint
    // fetch('/api/analytics', {
    //     method: 'POST',
    //     headers: { 'Content-Type': 'application/json' },
    //     body: JSON.stringify({ event: eventName, properties, timestamp: Date.now() })
    // }).catch(console.error);
}

// Track section visibility for engagement
function initSectionTracking() {
    const sectionObserver = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const sectionName = entry.target.className || entry.target.id || 'unknown';
                trackEvent('Section Viewed', {
                    section: sectionName,
                    visibility_percentage: Math.round(entry.intersectionRatio * 100)
                });
            }
        });
    }, {
        threshold: [0.5]
    });

    document.querySelectorAll('section').forEach(section => {
        sectionObserver.observe(section);
    });
}

// Initialize section tracking after page load
setTimeout(initSectionTracking, 1000);

// Performance optimization: Throttle scroll events
function throttle(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Page visibility tracking
document.addEventListener('visibilitychange', function() {
    if (document.hidden) {
        trackEvent('Page Hidden');
    } else {
        trackEvent('Page Visible');
    }
});

// Track time on page
let startTime = Date.now();
window.addEventListener('beforeunload', function() {
    const timeOnPage = Math.round((Date.now() - startTime) / 1000);
    trackEvent('Page Exit', { time_on_page_seconds: timeOnPage });
});

// Error handling
window.addEventListener('error', function(e) {
    console.error('JavaScript error:', e.error);
    trackEvent('JavaScript Error', {
        message: e.message,
        filename: e.filename,
        line: e.lineno
    });
});

// Form validation enhancements
function enhanceFormValidation() {
    const emailInput = document.getElementById('email');
    const nameInput = document.getElementById('name');
    
    if (emailInput) {
        emailInput.addEventListener('blur', function() {
            const email = this.value.trim();
            if (email && !isValidEmail(email)) {
                this.style.borderColor = '#EF4444';
                showFieldError(this, 'Proszę podać prawidłowy adres email');
            } else {
                this.style.borderColor = '';
                hideFieldError(this);
            }
        });
    }
    
    if (nameInput) {
        nameInput.addEventListener('blur', function() {
            const name = this.value.trim();
            if (name && name.length < 2) {
                this.style.borderColor = '#EF4444';
                showFieldError(this, 'Imię musi mieć co najmniej 2 znaki');
            } else {
                this.style.borderColor = '';
                hideFieldError(this);
            }
        });
    }
}

function showFieldError(field, message) {
    hideFieldError(field); // Remove existing error
    
    const error = document.createElement('div');
    error.className = 'field-error';
    error.textContent = message;
    error.style.cssText = `
        color: #EF4444;
        font-size: 12px;
        margin-top: 4px;
        display: block;
    `;
    
    field.parentNode.appendChild(error);
}

function hideFieldError(field) {
    const existingError = field.parentNode.querySelector('.field-error');
    if (existingError) {
        existingError.remove();
    }
}

// Initialize enhanced form validation
setTimeout(enhanceFormValidation, 100);

// Auto-save form data to localStorage (if user allows)
function initFormAutoSave() {
    const form = document.getElementById('founding-form');
    if (!form) return;
    
    const inputs = form.querySelectorAll('input[type="email"], input[type="text"]');
    
    // Load saved data
    inputs.forEach(input => {
        try {
            const saved = localStorage.getItem(`founding_form_${input.name}`);
            if (saved && input.type !== 'checkbox') {
                input.value = saved;
            }
        } catch (e) {
            // LocalStorage not available
        }
    });
    
    // Save data on input
    inputs.forEach(input => {
        input.addEventListener('input', function() {
            try {
                localStorage.setItem(`founding_form_${this.name}`, this.value);
            } catch (e) {
                // LocalStorage not available or full
                console.warn('Could not save form data:', e);
            }
        });
    });
    
    // Clear saved data on successful submission
    form.addEventListener('submit', function() {
        inputs.forEach(input => {
            try {
                localStorage.removeItem(`founding_form_${input.name}`);
            } catch (e) {
                // Ignore errors
            }
        });
    });
}

// Initialize auto-save after form is ready
setTimeout(initFormAutoSave, 500);

console.log('✨ All Mentavo AI Founding 100 features initialized successfully!');